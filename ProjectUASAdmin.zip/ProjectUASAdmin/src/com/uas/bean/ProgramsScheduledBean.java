package com.uas.bean;

import java.time.LocalDate;

public class ProgramsScheduledBean {
	private String programId;
	private String programName;
	private String city;
	private String state;
	private int zipCode;
	private LocalDate startDate;
	private LocalDate endDate;
	private byte sessionPerWeek;
	public ProgramsScheduledBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProgramsScheduledBean(String programId, String city, String state,
			int zipCode, LocalDate startDate, LocalDate endDate,
			byte sessionPerWeek) {
		super();
		this.programId = programId;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionPerWeek = sessionPerWeek;
	}
	public String getProgramId() {
		return programId;
	}
	public void setProgramId(String programId) {
		this.programId = programId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getZipCode() {
		return zipCode;
	}
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public byte getSessionPerWeek() {
		return sessionPerWeek;
	}
	public void setSessionPerWeek(byte sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}
	
	@Override
	public String toString() {
		return "ProgramsScheduledBean [programId=" + programId + ", city="
				+ city + ", state=" + state + ", zipCode=" + zipCode
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", sessionPerWeek=" + sessionPerWeek + "]";
	}
	
}
