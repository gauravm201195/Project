package com.uas.bean;

public enum UserRole{
	admin, mac;

	public static UserRole parse(String nextLine, UserRole role) {
		// TODO Auto-generated method stub
		return null;
	}	
}
