package com.uas.bean;

public enum UserRole{
	ADMIN, MAC;	
}
