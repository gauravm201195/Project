package com.uas.bean;

public class UserBean {
	private String loginId;
	private String password;
	private UserRole role;
	
	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserBean(String loginId, String password, UserRole role) {
		super();
		this.loginId = loginId;
		this.password = password;
		this.role = role;
	}
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserRole getRole() {
		return role;
	}
	public void setRole(UserRole role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "UserBean [loginId=" + loginId + ", password=" + password
				+ ", role=" + role + "]";
	}
	
}